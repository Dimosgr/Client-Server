Name: Dimosthenis
Surname: Tsatsos
ID: 100432956
===================================================================================================================

About the application:
----------------------

Is a live streaming client-server application.

The server sends small pieces of wave data of the song that have been choosing.

The client is a MFC application which receives the wave data from the server and plays them on time,
without waiting to receive the whole data.
===================================================================================================================

Instructions on how to run the application
------------------------------------------

You have to open first the .sln file of the server application with Visual Studio, build the app and run it. After that, you have
to open the .sln file of the client, build the app and run it.

I tried to release both of the projects and run both of them by their .exe files. I couldn make it because
to run the projects by .exe requires some .dll files.

The stop button does not work, for the reason that when the program plays the music, the buttons cant be pressed.