#include "stdafx.h"
#include <iostream>		//Include System
#include "Server.h"
#include "MusicStreaming.h"
#include <memory>

//CLASS IMPLEMENTATION
Server::Server(void)
{

}

Server::~Server(void)
{

}

void Server::wsaStartup()
{
	int _WSAStartup = WSAStartup(vrc, &wsaData);	//start the WSA
	if (_WSAStartup != 0)
	{
		cout << "WSA Startup has failed" << endl;
	}
	else { }
}

void Server::wsaCleanup()
{
	WSACleanup();	//just clean the WSA
}

sockaddr_in Server::hint()
{
	//sockaddr_in makeHint;
	hintStruct.sin_family = AF_INET;	//ip v4 to the hint struct
	hintStruct.sin_addr.S_un.S_addr = INADDR_ANY;
	hintStruct.sin_port = htons(54000);
	return hintStruct;	//create a standar sockaddr_in structure for the server
}

SOCKET Server::createServerSocket()
{
	serverSocket = socket(AF_INET, SOCK_STREAM, 0);		//AF_INET for IP v4, else(AF_INET6), SOCK_STREAM for TCP, else SOCK_DGRAM, 0
	if (serverSocket == INVALID_SOCKET)
	{
		cout << "Socket Creation Faild. Error number -> " << WSAGetLastError() << endl;
	}
	else { }
	return serverSocket;
}

SOCKET Server::acceptingSocket()
{
	clientSocket = accept(serverSocket, (SOCKADDR*)&client, &sizeOfClient);
	if (clientSocket == INVALID_SOCKET)
	{
		cout << "Socket Creation Faild. Error number -> " << WSAGetLastError() << endl;
	}
	else { }
	return clientSocket;
}

void Server::makeBind()
{
	_bind = bind(serverSocket, (SOCKADDR*)&hint(), sizeof(hint()));
	if (_bind == SOCKET_ERROR)
	{
		cout << "Binding Faild. Error number -> " << WSAGetLastError() << endl;
	}
	else { }
}

void Server::listening()
{
	listen(serverSocket, SOMAXCONN);
}

void Server::secureTheMemWithZeros()
{
	ZeroMemory(host, NI_MAXHOST);
	ZeroMemory(host, NI_MAXSERV);
}

void Server::clientsConnectedPort()
{
	if (getnameinfo((SOCKADDR*)&client, sizeof(client), host, NI_MAXHOST, service, NI_MAXSERV, 0) == 0)
	{
		cout << "A Client has connected on port ->	 " << service << endl;
	}
	else
	{
		inet_ntop(AF_INET, &client.sin_addr, host, NI_MAXHOST);
		cout << host << "A Client has connected on port ->	 " <<
			ntohs(client.sin_port) << endl;
	}
}

void Server::welcomeMessageForTheClient()
{
	unique_ptr<MusicStreaming> ptr_Music(new MusicStreaming());

	string welcomeMessage = "Hello. Please choose a song from the list: 	 \n" + ptr_Music->songList();
	unsigned long messageLength = htonl((unsigned long)welcomeMessage.size());	//my message to int
	send(clientSocket, welcomeMessage.c_str(), (int)welcomeMessage.size() + 1, 0);	//c_str converts a string to char[] for functions purposes
}

void Server::Test()
{
	unique_ptr<MusicStreaming> ptr_Music(new MusicStreaming());
	ptr_Music->Initialize();		//initialize the DirectSound

	int		nSize = 0;
	char*	pBuf = NULL;

	if (ptr_Music->ReadWaveFile(0, &nSize, &pBuf))
	{
		ptr_Music->PlayWaveBuffer(nSize, pBuf);
	}
}

void Server::communicate()
{
	unique_ptr<MusicStreaming> ptr_Music(new MusicStreaming());
	ptr_Music->Initialize();		//initialize the DirectSound

	int		nSize = 0;
	char*	pBuf = NULL;

	ZeroMemory(pRecvBuf, 4096);
	//wait for client to send data
	int bytesReceived = recv(clientSocket, pRecvBuf, 4096, 0);

	if (bytesReceived == SOCKET_ERROR)
	{
		cout << "Error in Receive!" << endl;
		comm = false;
	}
	else if (bytesReceived == 0)
	{
		cout << "Client disconnected....." << endl;
		comm = false;
	}
	else
	{
		string clientsMessage = string(pRecvBuf, 0, bytesReceived);

		// parse received message
		int nFileIndex = stoi(clientsMessage);
		nFileIndex--;
		if (!(0 <= nFileIndex && nFileIndex <= 6))
		{
			string errorMessage = "Unsupported choice.....";
			send(clientSocket, errorMessage.c_str(), (int)errorMessage.size() + 1, 0);
		}

		// read wave file
		ptr_Music->ReadWaveFile(nFileIndex, &nSize, &pBuf);

		// send wave buffer size
		char str[10];
		snprintf(str, sizeof(str), "%09d", nSize);
		send(clientSocket, str, sizeof(str), 0);

		// send the wave buffer
		int pos = 0;
		while (pos < nSize)
		{
			int nSendSize = min(BUF_UNIT, nSize - pos);
			int retval = 0;
			retval = send(clientSocket, pBuf + pos, nSendSize, 0);
			pos += retval;
		}
	}

	ptr_Music->Shutdown();	//clear the r_pointers to DirectSound interface
}

void Server::closingServerSocket()
{
	closesocket(serverSocket);
}

void Server::closingClientSocket()
{
	closesocket(clientSocket);
}