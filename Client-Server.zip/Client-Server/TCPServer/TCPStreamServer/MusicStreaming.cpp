#include "stdafx.h"
#include <iostream>
#include "MusicStreaming.h"

MusicStreaming::MusicStreaming()
{
	m_DirectSound = 0;
	m_primaryBuffer = 0;
	m_secondaryBuffer1 = 0;
}

MusicStreaming::~MusicStreaming()
{

}

string MusicStreaming::songList()
{
	string mySongList;

	for (int i = 0; i < 7; i++)
	{
		mySongList += mySongsForClient[i];		//+= to take all the songs
	}
	return mySongList;
}

bool MusicStreaming::Initialize()
{
	bool hr;

	// Initialize direct sound and the primary sound buffer.
	hr = InitializeDirectSound();
	if (!hr)
	{
		return false;
	}
	return true;
}

void MusicStreaming::Shutdown()
{
	// Release the secondary buffer.
	ShutdownWaveFile(&m_secondaryBuffer1);

	// Shutdown the Direct Sound API.
	ShutdownDirectSound();

	return;
}

bool MusicStreaming::InitializeDirectSound()
{
	HRESULT result;
	DSBUFFERDESC bufferDesc;
	WAVEFORMATEX waveFormat;


	// Initialize the direct sound interface pointer for the default sound device.
	result = DirectSoundCreate8(NULL, &m_DirectSound, NULL);
	if (FAILED(result))
	{
		return false;
	}

	// Set the cooperative level to priority so the format of the primary sound buffer can be modified.
	result = m_DirectSound->SetCooperativeLevel(GetConsoleWindow(), DSSCL_PRIORITY);				//EDW PREPEI NA DOSW ENA WINDOW ALLA DEN KSERW TI(evala auto GetConsoleWindow())
	if (FAILED(result))
	{
		return false;
	}

	// Setup the primary buffer description.
	bufferDesc.dwSize = sizeof(DSBUFFERDESC);
	bufferDesc.dwFlags = DSBCAPS_PRIMARYBUFFER | DSBCAPS_CTRLVOLUME;	//edw mipws xriastw na valw kai to DSBCAPS_GETCURRENTPOSITION2
	bufferDesc.dwBufferBytes = 0;										//edw to exei valei 48000 kanonika einai 0
	bufferDesc.dwReserved = 0;
	bufferDesc.lpwfxFormat = NULL;										//edw mipws prepei na tou valw &WaveFormat
	bufferDesc.guid3DAlgorithm = GUID_NULL;

	// Get control of the primary sound buffer on the default sound device.
	result = m_DirectSound->CreateSoundBuffer(&bufferDesc, &m_primaryBuffer, NULL);
	if (FAILED(result))
	{
		return false;
	}
	waveFormat.wFormatTag = WAVE_FORMAT_PCM;
	waveFormat.nSamplesPerSec = 44100;		//44,100 samples
	waveFormat.wBitsPerSample = 16;		//only 16 bits audio
	waveFormat.nChannels = 2;	//my buffer plays stereo
	waveFormat.nBlockAlign = (waveFormat.wBitsPerSample / 8) * waveFormat.nChannels;
	waveFormat.nAvgBytesPerSec = waveFormat.nSamplesPerSec * waveFormat.nBlockAlign;
	waveFormat.cbSize = 0;

	// Set the primary buffer to be the wave format specified.
	result = m_primaryBuffer->SetFormat(&waveFormat);
	if (FAILED(result))
	{
		return false;
	}

	return true;
}

void MusicStreaming::ShutdownDirectSound()
{
	// Release the primary sound buffer pointer.
	if (m_primaryBuffer)
	{
		m_primaryBuffer->Release();
		m_primaryBuffer = 0;
	}

	// Release the direct sound interface pointer.
	if (m_DirectSound)
	{
		m_DirectSound->Release();
		m_DirectSound = 0;
	}

	return;
}

void MusicStreaming::ShutdownWaveFile(IDirectSoundBuffer8** secondaryBuffer)
{
	// Release the secondary sound buffer.
	if (*secondaryBuffer)
	{
		(*secondaryBuffer)->Release();
		*secondaryBuffer = 0;
	}

	return;
}

bool MusicStreaming::ReadWaveFile(int nSongIndex, int* pSize, char** ppBuf)
{
	int	nSize = 0;
	static char* waveData = NULL;

	int error;
	FILE* filePtr;
	size_t count;
	WaveHeaderType waveFileHeader;

	// clear waveData
	if (waveData)
	{
		delete waveData;
		waveData = NULL;
	}

	// Open the wave file in binary.
	error = fopen_s(&filePtr, songs[nSongIndex], "rb");
	if (error != 0)
	{
		return true;
	}

	// Read in the wave file header.
	count = fread(&waveFileHeader, sizeof(waveFileHeader), 1, filePtr);
	if (count != 1)
	{
		return true;
	}

	// Check that the chunk ID is the RIFF format.
	if ((waveFileHeader.chunkId[0] != 'R') || (waveFileHeader.chunkId[1] != 'I') ||
		(waveFileHeader.chunkId[2] != 'F') || (waveFileHeader.chunkId[3] != 'F'))
	{
		return true;
	}

	// Check that the file format is the WAVE format.
	if ((waveFileHeader.format[0] != 'W') || (waveFileHeader.format[1] != 'A') ||
		(waveFileHeader.format[2] != 'V') || (waveFileHeader.format[3] != 'E'))
	{
		return true;
	}

	// Check that the sub chunk ID is the fmt format.
	if ((waveFileHeader.subChunkId[0] != 'f') || (waveFileHeader.subChunkId[1] != 'm') ||
		(waveFileHeader.subChunkId[2] != 't') || (waveFileHeader.subChunkId[3] != ' '))
	{
		return true;
	}

	// Check that the audio format is WAVE_FORMAT_PCM.
	if (waveFileHeader.audioFormat != WAVE_FORMAT_PCM)
	{
		return true;
	}

	// Check that the wave file was recorded in stereo format.
	if (waveFileHeader.numChannels != 2)
	{
		return true;
	}

	// Check that the wave file was recorded at a sample rate of 44.1 KHz.
	if (waveFileHeader.sampleRate != 44100)
	{
		return true;
	}

	// Ensure that the wave file was recorded in 16 bit format.
	if (waveFileHeader.bitsPerSample != 16)
	{
		return true;
	}

	// Check for the data chunk header.
	if ((waveFileHeader.dataChunkId[0] != 'd') || (waveFileHeader.dataChunkId[1] != 'a') ||
		(waveFileHeader.dataChunkId[2] != 't') || (waveFileHeader.dataChunkId[3] != 'a'))
	{
		return true;
	}

	// Get the data size
	nSize = waveFileHeader.dataSize;

	// Create wave buffer
	waveData = new char[nSize];
	if (!waveData)
	{
		return true;
	}

	// Read in the wave file data into the newly created buffer.
	count = fread(waveData, 1, nSize, filePtr);
	if (count != nSize)
	{
		return true;
	}

	// Close the file once done reading.
	fclose(filePtr);

	// return the data size and data buffer
	*pSize = nSize;
	*ppBuf = waveData;
	
	return true;
}

bool MusicStreaming::PlayWaveBuffer(int nSize, char* pBuf)
{
	// prepare the secondary buffer
	if (!PrepareSecondaryBuffer())
		return false;
	
	// play
	PlaySecondaryBuffer(nSize, pBuf);

	return true;
}

// Buffer size = 4 * BUF_UNIT
bool MusicStreaming::PrepareSecondaryBuffer()
{
	HRESULT result;

	WAVEFORMATEX waveFormat;
	DSBUFFERDESC bufferDesc;
	IDirectSoundBuffer* tempBuffer;

	// Set the wave format of secondary buffer that this wave file will be loaded onto.
	waveFormat.wFormatTag = WAVE_FORMAT_PCM;
	waveFormat.nSamplesPerSec = 44100;
	waveFormat.wBitsPerSample = 16;
	waveFormat.nChannels = 2;
	waveFormat.nBlockAlign = (waveFormat.wBitsPerSample / 8) * waveFormat.nChannels;
	waveFormat.nAvgBytesPerSec = waveFormat.nSamplesPerSec * waveFormat.nBlockAlign;
	waveFormat.cbSize = 0;

	// Set the buffer description of the secondary sound buffer that the wave file will be loaded onto.
	bufferDesc.dwSize = sizeof(DSBUFFERDESC);
	bufferDesc.dwFlags = DSBCAPS_CTRLVOLUME | DSBCAPS_GLOBALFOCUS | DSBCAPS_CTRLPOSITIONNOTIFY;
	bufferDesc.dwBufferBytes = 4 * BUF_UNIT;
	bufferDesc.dwReserved = 0;
	bufferDesc.lpwfxFormat = &waveFormat;
	bufferDesc.guid3DAlgorithm = GUID_NULL;

	// Create a temporary sound buffer with the specific buffer settings.
	result = m_DirectSound->CreateSoundBuffer(&bufferDesc, &tempBuffer, NULL);
	if (FAILED(result))
	{
		return false;
	}

	// Test the buffer format against the direct sound 8 interface and create the secondary buffer.
	result = tempBuffer->QueryInterface(IID_IDirectSoundBuffer8, (void**)&m_secondaryBuffer1);
	if (FAILED(result))
	{
		return false;
	}

	// Release the temporary buffer.
	tempBuffer->Release();
	tempBuffer = 0;

	return true;
}

void read_buffer(int nSize, char* pBuf, int& pos, void* data, int size)
{
	if (!data)
		return;
	if ((nSize - pos) < size)
	{
		int i = 0;
	}

	size = min(size, nSize - pos);

	memcpy(data, pBuf + pos, size);
	pos += size;
}

void MusicStreaming::PlaySecondaryBuffer(int nSize, char* pBuf)
{
	int pos = 0;
	HRESULT result;
	unsigned char*	bufferPtr1;
	unsigned long   bufferSize1;
	unsigned char*	bufferPtr2;
	unsigned long   bufferSize2;

	DWORD soundBytesOutput = 0;
	bool fillFirstHalf = true;
	LPDIRECTSOUNDNOTIFY8 directSoundNotify;
	DSBPOSITIONNOTIFY positionNotify[2];

	// Set position 0
	result = m_secondaryBuffer1->SetCurrentPosition(0);
	if (FAILED(result)) return;

	// Set volume of the buffer to 100%.
	result = m_secondaryBuffer1->SetVolume(DSBVOLUME_MAX);
	if (FAILED(result)) return;

	HANDLE playEventHandles[2];
	playEventHandles[0] = CreateEvent(NULL, FALSE, FALSE, NULL);
	playEventHandles[1] = CreateEvent(NULL, FALSE, FALSE, NULL);

	result = m_secondaryBuffer1->QueryInterface(IID_IDirectSoundNotify8, (LPVOID*)&directSoundNotify);
	if (FAILED(result)) return;

	positionNotify[0].dwOffset = BUF_UNIT;
	positionNotify[0].hEventNotify = playEventHandles[0];
	positionNotify[1].dwOffset = BUF_UNIT * 3;
	positionNotify[1].hEventNotify = playEventHandles[1];
	directSoundNotify->SetNotificationPositions(2, positionNotify);

	// Initial play buffer
	result = m_secondaryBuffer1->Lock(0, BUF_UNIT * 2, (void**)&bufferPtr1, (DWORD*)&bufferSize1, (void**)&bufferPtr2, (DWORD*)&bufferSize2, 0);
	if (FAILED(result)) return;

	// Copy the wave data into the buffer. If you need to insert some silence into the buffer, insert values of 0.
	read_buffer(nSize, pBuf, pos, bufferPtr1, bufferSize1);
	read_buffer(nSize, pBuf, pos, bufferPtr2, bufferSize2);

	// Unlock the secondary buffer after the data has been written to it.
	result = m_secondaryBuffer1->Unlock((void*)bufferPtr1, bufferSize1, (void*)bufferPtr2, bufferSize2);
	if (FAILED(result)) 
		return;

	// Start play
	m_secondaryBuffer1->Play(0, 0, DSBPLAY_LOOPING);

	while (true)
	{
		// Wait for notifications.
		result = WaitForMultipleObjects(2, playEventHandles, FALSE, INFINITE);

		if (WAIT_OBJECT_0 == result)
		{
			//Lock DirectSoundBuffer Second Part
			HRESULT hr = m_secondaryBuffer1->Lock(2 * BUF_UNIT, 2 * BUF_UNIT,
				(void**)&bufferPtr1, (DWORD*)&bufferSize1, (void**)&bufferPtr2, (DWORD*)&bufferSize2, 0);
			if (FAILED(hr)) return;
		}
		else if (WAIT_OBJECT_0 + 1 == result)
		{
			//Lock DirectSoundBuffer First Part
			HRESULT hr = m_secondaryBuffer1->Lock(0, 2 * BUF_UNIT, (void**)&bufferPtr1, (DWORD*)&bufferSize1,
				(void**)&bufferPtr2, (DWORD*)&bufferSize2, 0);
			if (FAILED(hr)) return;
		}
		else return;

		// Read buffer
		read_buffer(nSize, pBuf, pos, bufferPtr1, bufferSize1);
		read_buffer(nSize, pBuf, pos, bufferPtr2, bufferSize2);

		//Unlock DirectSoundBuffer
		m_secondaryBuffer1->Unlock(bufferPtr1, bufferSize1, bufferPtr2, bufferSize2);
		if (pos >= nSize)
		{
			break;
		}
	}

	directSoundNotify->Release();
	CloseHandle(playEventHandles[0]);
	CloseHandle(playEventHandles[1]);
}

void MusicStreaming::ReleaseSecondaryBuffer()
{
	if (m_secondaryBuffer1)
	{
		m_secondaryBuffer1->Release();
		m_secondaryBuffer1 = 0;
	}
}