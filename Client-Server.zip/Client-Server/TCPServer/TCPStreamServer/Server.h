#include <WS2tcpip.h>
#include <string>

using namespace std;

class Server
{
public:
	bool comm = true;

	//constractor and destructor
	Server();
	~Server();

	void wsaStartup();

	void wsaCleanup();

	sockaddr_in hint();	//method that returns me a filled struct for the servers details

	SOCKET createServerSocket();	//create a server socket

	SOCKET acceptingSocket();	//accept a socket

	void makeBind();

	void listening();

	void closingServerSocket();

	void closingClientSocket();

	void clientsConnectedPort();

	void secureTheMemWithZeros();

	void Test();

	void communicate();

	void welcomeMessageForTheClient();

private:
	WSADATA wsaData;	//pointer to wsa data
	WORD vrc = MAKEWORD(2, 2);		//version

	SOCKET serverSocket;	//socket server
	SOCKET clientSocket;	//socket client
	sockaddr_in client;		//struct for clients details
	sockaddr_in hintStruct;	//struckt for servers details

	char pRecvBuf[4096];

	char host[NI_MAXHOST];	//clients remote name
	char service[NI_MAXSERV];	//clients port connected

	int _bind;
	int sizeOfClient = sizeof(client);
};