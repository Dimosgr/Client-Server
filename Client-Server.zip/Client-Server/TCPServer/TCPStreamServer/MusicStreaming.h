#pragma once
#include <string>
#include "resource.h"
#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>
#include <stdio.h>
#include <iostream>

//libraries to use the DirectSound
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "winmm.lib")

#define	DIRECT_SOUND_CREATE(name) HRESULT WINAPI name(LPCGUID pcGuidDevice, LPDIRECTSOUND *ppDS, LPUNKNOWN pUnkOuter);
typedef DIRECT_SOUND_CREATE(direct_sound_create);

using namespace std;

#define BUF_UNIT	10240

class MusicStreaming
{
public:
	MusicStreaming();
	~MusicStreaming();

	bool ReadWaveFile(int nSongIndex, int* pSize, char** ppBuf);
	bool PlayWaveBuffer(int nSize, char* pBuf);
	bool Initialize();
	void Shutdown();

	string songList();
private:
	bool InitializeDirectSound();
	void ShutdownDirectSound();
	bool PrepareSecondaryBuffer();
	void PlaySecondaryBuffer(int nSize, char* pBuf);
	void ReleaseSecondaryBuffer();
	void ShutdownWaveFile(IDirectSoundBuffer8**);

	IDirectSound8* m_DirectSound;
	IDirectSoundBuffer* m_primaryBuffer;
	IDirectSoundBuffer8* m_secondaryBuffer1;

	struct WaveHeaderType
	{
		char chunkId[4];
		unsigned long chunkSize;
		char format[4];
		char subChunkId[4];
		unsigned long subChunkSize;
		unsigned short audioFormat;
		unsigned short numChannels;
		unsigned long sampleRate;
		unsigned long bytesPerSecond;
		unsigned short blockAlign;
		unsigned short bitsPerSample;
		char dataChunkId[4];
		unsigned long dataSize;
	};

	//Here is the path of my songs
	char* firstSong = "..\\Songs\\Track1.wav";
	char* secondSong = "..\\Songs\\Track2.wav";
	char* thirdSong = "..\\Songs\\Track3.wav";
	char* fourthSong = "..\\Songs\\Track4.wav";
	char* fifthSong = "..\\Songs\\Track5.wav";
	char* sixthSong = "..\\Songs\\Track6.wav";
	char* seventhSong = "..\\Songs\\Track7.wav";
	//array with the path of the songs() this array helps the method Load to load the files
	char* songs[7] = { firstSong, secondSong, thirdSong, fourthSong, fifthSong, sixthSong, seventhSong };


	//Names of the songs
	char* firstTrack = "Press 1 for:	The Welcome Song!!\n";
	char* secondTrack = "Press 2 for:	Kid Learning\n";
	char* thirdTrack = "Press 3 for:	Crisp Sound\n";
	char* fourthTrack = "Press 4 for:	Bantam To Wake You Up\n";
	char* fifthTrack = "Press 5 for:	Rainy Day In The Town\n";
	char* sixthTrack = "Press 6 for:	Magic Music\n";
	char* seventhTrack = "Press 7 for:	Ravers Party\n";
	//Here is a vector to pass the songs to the client
	char* mySongsForClient[7] = { firstTrack, secondTrack, thirdTrack, fourthTrack, fifthTrack, sixthTrack, seventhTrack };
};