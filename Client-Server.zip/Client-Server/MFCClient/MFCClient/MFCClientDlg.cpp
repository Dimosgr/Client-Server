#include "stdafx.h"
#include "MFCClient.h"
#include "MFCClientDlg.h"
#include "afxdialogex.h"
#include "ClientsClass.h"
#include "PlayMusic.h"
#include <memory>
#include <string>

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	DECLARE_MESSAGE_MAP()
};


unique_ptr<ClientsClass> ptr_client(new ClientsClass);		//initialize my smart pointer for client class...

unique_ptr<PlayMusic> ptr_music(new PlayMusic);				//initialize my smart pointer for music class...


CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


CMFCClientDlg::CMFCClientDlg(CWnd* pParent)
	: CDialogEx(IDD_MFCCLIENT_DIALOG, pParent)
	, list(_T(""))
	, usersInput(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, ListOfSongs, list);
	DDX_Text(pDX, ClientsInput, usersInput);
}

BEGIN_MESSAGE_MAP(CMFCClientDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(ClientsInput, &CMFCClientDlg::OnEnChangeClientsinput)
	ON_BN_CLICKED(IDR_MAINFRAME, &CMFCClientDlg::OnBnClickedMainframe)
	ON_BN_CLICKED(IDCANCEL, &CMFCClientDlg::OnBnClickedCancel)
	ON_STN_CLICKED(ListOfSongs, &CMFCClientDlg::OnStnClickedListofsongs)
	ON_BN_CLICKED(IDC_StopBtn, &CMFCClientDlg::OnBnClickedStopbtn)
END_MESSAGE_MAP()

BOOL CMFCClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}


	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	//Initialize everything here
	ptr_client->wsaStartup();
	ptr_client->hint();
	ptr_client->createSocket();
	ptr_client->connection();
	string _list = ptr_client->receiveMessage();	//my list of songs to string
	list = _list.c_str();	//make my list a CString
	SetDlgItemText(ListOfSongs, list);

	return TRUE;
}

void CMFCClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

void CMFCClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);

		
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

HCURSOR CMFCClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMFCClientDlg::OnEnChangeClientsinput()
{
	//EMPTY
}


void CMFCClientDlg::OnBnClickedMainframe()
{
	HWND hWnd = AfxGetApp()->m_pMainWnd->m_hWnd;	//take the main window of the app to play the song

	GetDlgItemText(ClientsInput, usersInput);	//every time he presses the button im taking the input
	CT2CA pszConvertedAnsiString(usersInput);	//convert a TCHAR string to a LPCSTR
	string input = pszConvertedAnsiString;		//construct a string using the LPCSTR input
	if (input == "1" || input == "2" || input == "3" || input == "4" || input == "5" || input == "6" || input == "7")
	{
		CString error(" ");
		SetDlgItemText(ErrorMessage, error);
		ptr_client->communication(input, hWnd);
	}
	else
	{
		CString error ("unsuported choice! Please chose a number from the List!");
		SetDlgItemText(ErrorMessage, error);
	}
}


void CMFCClientDlg::OnBnClickedCancel()
{
	//close everything and close the app
	ptr_client->closeTheSocket();
	ptr_client->wsaCleanup();
	ptr_music->Shutdown();		//Shutdown the DirectSound
	CDialogEx::OnCancel();
}


void CMFCClientDlg::OnStnClickedListofsongs()
{
	//EMPTY
}


void CMFCClientDlg::OnBnClickedStopbtn()
{
	//ptr_music->stop();
}
