#include <WS2tcpip.h>	//the windows socket library
#include <string>

using namespace std;

class ClientsClass
{
public:
	//constructor and destructor
	ClientsClass();
	~ClientsClass();

	void wsaStartup();		//start my WSA to create sockets
	void wsaCleanup();		//clean the WSA

	sockaddr_in hint();		//fill the struct with the details that i want and get it back

	SOCKET createSocket();		//creates a socket

	void connection();		//make connection to the socket
	string receiveMessage();		//receiving messages from the server
	void communication(string choice, HWND hwnd);		//communicate with server in general until you send its Exit (edw mporei na thelei parametro to userInput na to dw)
	void closeTheSocket();		//closing the socket

private:
	const string serversIP = "127.0.0.1";		//is the local ip of the device
	const int port = 54000;		//the port that i want to connect
	char buf[4096];
	string userInput;	//string that user wants to send to the server

	int conn;	//variable for error handling in the connection function

	WSAData wsaData;	//the WSA variable
	WORD vrc = MAKEWORD(2, 2);		//the version of the winsock

	SOCKET clientSocket;	//the socket that i want to implement
	sockaddr_in hintStruct;		//the struct that i want to fill
};