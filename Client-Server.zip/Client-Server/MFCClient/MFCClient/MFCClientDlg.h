
// MFCClientDlg.h : header file
//

#pragma once


// CMFCClientDlg dialog
class CMFCClientDlg : public CDialogEx
{
// Construction
public:
	CMFCClientDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCCLIENT_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeClientsinput();
	afx_msg void OnBnClickedMainframe();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnStnClickedListofsongs();
	//AUTA SINDEONTE TWRA ME TA KOUTIA TIS FORMAS
	CString list;	//list of songs
	CString usersInput;		//to input tou xristi gia na dialeksei tragoudi
	afx_msg void OnBnClickedStopbtn();
};
