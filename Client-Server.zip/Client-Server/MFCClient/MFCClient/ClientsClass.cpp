#include "stdafx.h"
#include <iostream>
#include "ClientsClass.h"
#include "PlayMusic.h"
#include <memory>

//CLASS IMPLEMENTATION
ClientsClass::ClientsClass(void)
{
	//the constructor
}

ClientsClass::~ClientsClass(void)
{
	//the destructor
}

void ClientsClass::wsaStartup()
{
	int _wsaStartup = WSAStartup(vrc, &wsaData);	//WSAStartup needs the version and a pointer to the WSA data
	if (_wsaStartup != 0)	//I want to returns 0 else mean that id doesnt work
	{
		cout << "WSA Startup has failed" << endl;
	}
	else { }
}

void ClientsClass::wsaCleanup()
{
	WSACleanup();	//just use the WSACleanup method to clean my winsock
}

sockaddr_in ClientsClass::hint()
{
	hintStruct.sin_family = AF_INET;	//make sin_family to have ip v 4 (for 6 is:		AF_INET6)
	//put the 5400 port to the struct (htons function wants an u_short number: is an int between 0 and 65535 and converts it from host to TCP/IP network bytes order)
	hintStruct.sin_port = htons(port);
	inet_pton(AF_INET, serversIP.c_str(), &hintStruct.sin_addr);
	return hintStruct;
}

SOCKET ClientsClass::createSocket()
{
	clientSocket = socket(AF_INET, SOCK_STREAM, 0);//socket fun needs(version of the IP, type of the socket(SOCK_STREAM: TCP, SOCK_DGRAM: UDP), and the protocol)
	if (clientSocket == INVALID_SOCKET)
	{
		cout << "Socket Creation Faild. Error number -> " << WSAGetLastError() << endl;
		WSACleanup();
	}
	else { }
	return clientSocket;
}

void ClientsClass::connection()
{
	conn = connect(clientSocket, (sockaddr*)&hintStruct, sizeof(hintStruct));
	if (conn == SOCKET_ERROR)
	{
		cout << "Connection Failed.	Error ->	" << WSAGetLastError() << endl;
		closesocket(clientSocket);
		WSACleanup();
	}
	else { }
}

string ClientsClass::receiveMessage()
{
	int messageToReceive = recv(clientSocket, buf, 4096, 0);	//you receive a message like an integer and you have to make it a string
	return string(buf, 0, messageToReceive);		//thats how to print a message.
}

void ClientsClass::communication(string choice, HWND hwnd)
{
	unique_ptr<PlayMusic> ptr_Music(new PlayMusic());
	
	ptr_Music->Initialize(hwnd);		//initialize the DirectSound

	//send the text to the server
	size_t sendResult = send(clientSocket, choice.c_str(), (int)choice.size() + 1, 0);	//Is plus 1 for the /0
	if (sendResult != SOCKET_ERROR)
	{
		// receive
		char str[10];
		recv(clientSocket, str, 10, 0);

		// parse
		int nSize = 0;
		sscanf(str, "%d", &nSize);

		// play
		ptr_Music->PlayWaveBuffer(nSize, clientSocket);
	}	
}

void ClientsClass::closeTheSocket()
{
	closesocket(clientSocket);
}