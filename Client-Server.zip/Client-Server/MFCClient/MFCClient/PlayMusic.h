#pragma once
#include <string>
#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>
#include <stdio.h>
#include <iostream>

//libraries to use the DirectSound
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "winmm.lib")

#define	DIRECT_SOUND_CREATE(name) HRESULT WINAPI name(LPCGUID pcGuidDevice, LPDIRECTSOUND *ppDS, LPUNKNOWN pUnkOuter);
typedef DIRECT_SOUND_CREATE(direct_sound_create);

using namespace std;

#define BUF_UNIT	10240

class PlayMusic
{
public:
	PlayMusic();
	~PlayMusic();

	bool PlayWaveBuffer(int nSize, SOCKET clientSocket);	//plays wave data from the server
	bool Initialize(HWND hwnd);								//creates the pointers to use the API
	bool stop();											//stop the buffer
	void Shutdown();										//releases the pointers of the API
private:
	bool InitializeDirectSound(HWND hwnd);
	void ShutdownDirectSound();
	bool PrepareSecondaryBuffer();
	void PlaySecondaryBuffer(int nSize, SOCKET clientSocket);
	void ReleaseSecondaryBuffer();
	void ShutdownWaveFile(IDirectSoundBuffer8**);
	bool stopWaveFile();

	//My pointers
	IDirectSound8* m_DirectSound;
	IDirectSoundBuffer* m_primaryBuffer;
	IDirectSoundBuffer8* m_secondaryBuffer1;

	//type of the songs
	struct WaveHeaderType
	{
		char chunkId[4];
		unsigned long chunkSize;
		char format[4];
		char subChunkId[4];
		unsigned long subChunkSize;
		unsigned short audioFormat;
		unsigned short numChannels;
		unsigned long sampleRate;
		unsigned long bytesPerSecond;
		unsigned short blockAlign;
		unsigned short bitsPerSample;
		char dataChunkId[4];
		unsigned long dataSize;
	};
};